public class MyQueue {
    private int maxSize;
    private int front;
    private int rear;
    private int[] queueArray;

    public MyQueue(int size) {
        this.maxSize = size;
        this.queueArray = new int[maxSize];
        this.front = 0;
        this.rear = -1;
    }

    public void enqueue(int value) {
        if (rear < maxSize - 1) {
            queueArray[++rear] = value;
        } else {
            System.out.println("Очередь переполнена");
        }
    }

    public int dequeue() {
        if (front <= rear) {
            return queueArray[front++];
        } else {
            System.out.println("Очередь пуста");
            return -1;
        }
    }

    public int peek() {
        if (front <= rear) {
            return queueArray[front];
        } else {
            System.out.println("Очередь пуста");
            return -1;
        }
    }

    public boolean isEmpty() {
        return (front > rear);
    }

    public static void main(String[] args) {
        MyQueue queue = new MyQueue(5);

        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);

        System.out.println("Front элемент очереди: " + queue.peek());

        System.out.println("Dequeue элемент: " + queue.dequeue());
        System.out.println("Dequeue элемент: " + queue.dequeue());

        System.out.println("Стек пуст? " + queue.isEmpty());

        queue.enqueue(4);
        queue.enqueue(5);
        queue.enqueue(6);

        System.out.println("Front элемент очереди: " + queue.peek());
    }
}
