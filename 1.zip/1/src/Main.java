public class MyStack {
    private int maxSize;
    private int top;
    private int[] stackArray;

    public MyStack(int size) {
        this.maxSize = size;
        this.stackArray = new int[maxSize];
        this.top = -1;
    }

    public void push(int value) {
        if (top < maxSize - 1) {
            stackArray[++top] = value;
        } else {
            System.out.println("Стек переполнен");
        }
    }

    public int pop() {
        if (top >= 0) {
            return stackArray[top--];
        } else {
            System.out.println("Стек пуст");
            return -1;
        }
    }

    public int peek() {
        if (top >= 0) {
            return stackArray[top];
        } else {
            System.out.println("Стек пуст");
            return -1;
        }
    }

    public boolean isEmpty() {
        return (top == -1);
    }

    public static void main(String[] args) {
        MyStack stack = new MyStack(5);

        stack.push(1);
        stack.push(2);
        stack.push(3);

        System.out.println("Top элемент стека: " + stack.peek());

        System.out.println("Pop элемент: " + stack.pop());
        System.out.println("Pop элемент: " + stack.pop());
        System.out.println("Pop элемент: " + stack.pop());

        System.out.println("Стек пуст? " + stack.isEmpty());
    }
}
