import java.util.ArrayList;
import java.util.List;

public class CustomSet {
    private List<Integer> elements;

    public CustomSet() {
        this.elements = new ArrayList<>();
    }

    public void add(int element) {
        if (!contains(element)) {
            elements.add(element);
        }
    }

    public void remove(int element) {
        elements.remove(Integer.valueOf(element));
    }

    public boolean contains(int element) {
        return elements.contains(element);
    }

    public void display() {
        for (int element : elements) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        CustomSet set = new CustomSet();

        set.add(1);
        set.add(2);
        set.add(3);
        set.add(2); // Дубликат не будет добавлен

        System.out.println("Элементы множества:");
        set.display();

        set.remove(2);

        System.out.println("Элементы множества после удаления:");
        set.display();
    }
}
