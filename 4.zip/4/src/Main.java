import java.util.ArrayList;
import java.util.List;

class TreeNode {
    int value;
    List<TreeNode> children;

    public TreeNode(int value) {
        this.value = value;
        this.children = new ArrayList<>();
    }

    // Метод для добавления дочернего узла
    public void addChild(TreeNode child) {
        children.add(child);
    }
}

public class NaryTree {
    TreeNode root;

    public NaryTree(int rootValue) {
        this.root = new TreeNode(rootValue);
    }

    // Метод для обхода дерева в глубину (DFS)
    public void depthFirstTraversal(TreeNode node) {
        if (node == null) return;

        System.out.print(node.value + " ");

        for (TreeNode child : node.children) {
            depthFirstTraversal(child);
        }
    }

    // Метод для обхода дерева в ширину (BFS)
    public void breadthFirstTraversal() {
        if (root == null) return;

        List<TreeNode> queue = new ArrayList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            TreeNode current = queue.remove(0);
            System.out.print(current.value + " ");

            queue.addAll(current.children);
        }
    }

    public static void main(String[] args) {
        NaryTree tree = new NaryTree(1);

        TreeNode child1 = new TreeNode(2);
        TreeNode child2 = new TreeNode(3);
        TreeNode child3 = new TreeNode(4);
        tree.root.addChild(child1);
        tree.root.addChild(child2);
        tree.root.addChild(child3);

        TreeNode child1_1 = new TreeNode(5);
        TreeNode child1_2 = new TreeNode(6);
        child1.addChild(child1_1);
        child1.addChild(child1_2);

        System.out.println("Обход дерева в глубину (DFS):");
        tree.depthFirstTraversal(tree.root);

        System.out.println("\nОбход дерева в ширину (BFS):");
        tree.breadthFirstTraversal();
    }
}
